package poker;

import java.util.Arrays;

public class Deck {

	private Card[] cards;

	public Deck() {
		cards = new Card[52];
		int count = 0;
		for (int i = 0; i < 4; i++) {
			for (int a = 1; a <= 13; a++) {
				cards[count] = new Card(a, i);
				count++;
			}

		}
	}

	public Deck(Deck other) {
		this.cards = other.cards;
	}

	public Card getCardAt(int position) {
		return cards[position];
	}

	public int getNumCards() {
		return cards.length;
	}

	public void shuffle() {
		int newDeckIndex = 0;
		int newDeckIndex2 = 0;
		Card[] newDeck = new Card[cards.length / 2];
		Card[] newDeck2 = new Card[cards.length / 2];
		if ((cards.length % 2) != 0) {
			newDeck = new Card[newDeck.length + 1];
		}
		for (int i = 0; i < newDeck.length; i++) {
			newDeck[newDeckIndex] = cards[i];
			newDeckIndex++;
		}
		for (int a = newDeck.length; a < cards.length; a++) {
			newDeck2[newDeckIndex2] = cards[a];
			newDeckIndex2++;
		}
		int newIndex = 0;
		int newIndex2 = 0;
		for (int j = 0; j < cards.length; j++) {
			if (j % 2 == 0) {
				cards[j] = newDeck[newIndex];
				newIndex++;// this for loop is to help shuffle the deck..taking from both the top and
							// bottom
			} else {
				cards[j] = newDeck2[newIndex2];
				newIndex2++;
			}
		}
	}

	public void cut(int position) {
		Card[] top = new Card[position]; // this is the top of the card
		Card[] bottom = new Card[cards.length - position];// this is the bottom of the card
		int index = position;
		int b = 0;

		for (int i = 0; i < top.length; i++) {
			top[i] = cards[i];
		}
		for (int a = 0; a < bottom.length; a++) {
			bottom[a] = cards[index++];

		}
		
		for (int j = 0; j < cards.length; j++) {
			if (j < bottom.length) {
				cards[j] = bottom[j];
			} else {
				cards[j] = top[b++];
			}
		}
	}

	public Card[] deal(int numCards) {
		Card[] smaller = new Card[cards.length - numCards];
		Card[] dealt = new Card[numCards];
		int index = 0;

		for (int i = 0; i < numCards; i++) {
			dealt[i] = cards[index];
			index++;
		}
		for (int a = 0; a < smaller.length; a++) {
			smaller[a] = cards[index];
			index++;
		}
		cards = new Card[smaller.length];
		for (int j = 0; j < smaller.length; j++) {
			this.cards[j] = smaller[j];

		}
		return dealt;
	}

	public String toString() {
		return Arrays.toString(cards);
	}

}
